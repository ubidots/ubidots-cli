data = {
    "msg": "Welcome User",
    "opt": "Advanced Options Enabled",
    "user_id": "user_12345",
    "request_id": "req_67890"
}

def main(args):

	return {
        "status_code": 200,
        "results": data,
		"payload": args,
    }
