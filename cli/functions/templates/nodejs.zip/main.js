/*
* This code demonstrates a simple HTTP endpoint that receives an Ubidots token
* and a temperature value as URL parameters, then uses this data to make an
* HTTP POST request to Ubidots API.
*
* You can build a URL as explained below, and paste it into your web browser to
* test the function. Example:
*
* https://parse.ubidots.com/{your-function-URL}/?token={YOUR-TOKEN}&device=sample-function&temperature=45
*
* Example by: Dev Team @Ubidots
*/

// Import the 'axios' library so we can make HTTP request from the function
const axios = require('axios');

// Main function - runs every time the function is executed.
// "args" is a dictionary containing both the URL params and the HTTP body (for POST requests).
async function main(args) {

  // Grab the token and device label from URL parameters, then erase them from the args dictionary
  var ubidots_token = args.token;
  var device_label = args.device;
  delete args['token'];
  delete args['device'];

  // Use the remaining parameters as payload
  var payload = args;

  // Log the payload to the console, for debugging purposes. You may access the function's logs using
  // the option in the above header.
  console.log(payload);

  // Send the payload to Ubidots
  var response = await ubidots_request(ubidots_token, device_label, payload);

  // Log Ubidots response to the console
  console.log(response);

  // Pass Ubidots' API response as the function's reponse
  return response;
}

// This function builds an HTTP POST request to Ubidots
async function ubidots_request(token, label, body) {
  let config = {
    method: 'post',
    url: 'https://industrial.api.ubidots.com/api/v1.6/devices/' + label,
    data: body,
    headers: {
      'Content-Type': 'application/json',
      'X-Auth-Token': token
    }
  }
  const response = await axios.request(config);
  return response.data;
}
