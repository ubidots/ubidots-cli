function main(args) {
    console.log("Hello World!");
}
module.exports.main = main;

